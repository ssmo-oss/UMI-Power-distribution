# D4 fabrication and assembly specification — ten prototypes of each board

Use the per-board Gerber and drill files as one matched set. Do not combine layers or position files from different revisions. The four copper layers are F.Cu, In1.Cu, In2.Cu and B.Cu in that order.

| Setting | USB_POWER | MAIN_POWER |
|---|---|---|
| Layer count | 4 | 4 |
| Finished thickness | 1.6 mm | 1.2 mm |
| Outer copper | 2 oz / nominal 70 µm | 2 oz / nominal 70 µm |
| Inner copper | 1 oz / nominal 35 µm | 1 oz / nominal 35 µm |
| Finish | ENIG | ENIG |
| Mask / legend | Green / white | Green / white |
| Via-in-pad process | Resin filled and copper capped | Resin filled and copper capped |
| SMT placement | Top side only | Top side only |
| Manual parts | Input and USB sockets | Connectors and fuse holders; fuse inserts fitted separately |

FR-4 construction, nominal Tg at least 150 °C. No controlled-impedance routing is specified. The dielectric splits in the KiCad stackup are nominal; the fabricator may propose its standard construction with the specified total thickness and copper weights. Do not silently change to 0.5 oz inner copper. Final material, tolerances and assembly process must be accepted in the manufacturing quote.

Main board thickness is deliberately below the fuse holder's 1.5 mm PCB limit. A 1.6 mm main board is not an approved substitution. USB and main boards therefore need separate fabrication settings/panels.

**Filled and capped vias are essential beneath exposed solder pads.** Ordinary tenting, solder-mask plugging, or leaving these holes open is not equivalent. The drill files include the vias; the fabricator must apply the specified process. The Gerber preview displays drill positions even where the finished process will cap them. Choose a via-in-pad / POFV process in the quote and ensure the assembler agrees with it.

Gerbers, Excellon drills and component positions share the board's drill/place origin. USB origin is its bottom-left outline corner. Gerber outline strokes are 0.05 mm wide: the USB centreline outline is exactly 80 × 50 mm even though the Gerber-job graphical bounding box is 80.05 × 50.05 mm. Cut along the outline centreline.

The manufacturing folder contains the four copper layers, two solder masks, two legends, outline, plated and non-plated drills, and the Gerber job description. The assembly folder separately contains top paste and the SMT position files. Do not interpret absence of paste in the bare-board Gerber ZIP as absence of stencil data.

## Assembly handoff

- BOM_by_reference.csv is the complete installed electrical-parts list; mounting holes are excluded from purchasing.
- BOM_grouped.csv groups equal ordering parts and local footprints.
- BOM_JLC_DRAFT.csv has known catalog matches and exact manufacturer MPNs. Blank catalog codes require sourcing; they are not approved substitutions. A populated catalogue code is a sourcing reference, not stock reservation or assembler acceptance. Main J1 and R1 remain exact-part procurement/preorder items; consult the D4 procurement status.
- The native KiCad positions and the JLC-formatted CPL contain only SMT parts. Through-hole connectors and fuse holders are intentionally omitted for hand fitting.
- Verify the assembler's placement preview against the pin-1 marks and the assembly drawing. KiCad rotation zero is not a universal guarantee of every assembler's component-library orientation.
- Confirm stencil treatment of thermal pads and the heavy Coilcraft inductor's support fixture with the assembler. All specified SMT parts are intended for assembly service, including the power modules/inductors.
- No substitute with the same generic name but a different manufacturer is approved for AO4407A or USBLC6-2SC6.

Only the D4 verification records establish which exported files and checks passed. Do not inherit a D3 pass result after a source change. This does not replace a manufacturer's DFM review. These are first-prototype files, not evidence of physical qualification or certification. Follow ENGINEERING_AND_TEST_NOTES.md before connecting the actual devices.

Fabricator capability source checked 2026-09-26: [JLCPCB capabilities](https://jlcpcb.com/capabilities/Capab). Relevant published limits include multilayer 2 oz track/space 0.15/0.15 mm, ordinary via-hole range and annular guidance, minimum 1 mm legend text, and filled/plated-over via-in-pad processing. This document is a requested build specification; no manufacturing quote or order has been submitted.

## Placement rotation normalization

Use *_CPL_JLC.csv with BOM_JLC_DRAFT.csv for the assembly quote. These files normalize rotated local footprint geometry to the unrotated source package, using independently checked pad coordinates. The raw *_positions.csv files retain KiCad local-footprint rotations and must not be substituted blindly. Main U1/Q1/Q2/Q3 normalize to 90 degrees, C19/C20 to 270 degrees. The complete per-reference table is in verification/rotation_corrections.json. Supplier package zero-angle conventions still require placement-preview review.


## D4 handoff conditions

Build quantity is ten MAIN_POWER plus ten USB_POWER boards. Board outline, mounting holes, thickness and copper specification are unchanged by the procurement revision. Main shunt R2 has new manufacturer-recommended pads (2.60 × 3.68 mm, 2.55 mm gap); this requires fresh D4 copper/connectivity and stencil review. Do not reuse the D3 paste file.

Fuse holders are now Littelfuse 178.6165.0002, a packaging-only change from .0001. Insert values remain 7.5 A, 7.5 A, 1 A, 5 A, 10 A and 3 A; the last insert is rated 80 V DC. The exact inserts appear in MANUAL_ASSEMBLY.md. No Nano2 or electronic-fuse redesign was adopted.

Use the D4 normalized CPL and its matching BOM only. Verify every substituted part against the assembler's library/pin-1 preview. Reserve sufficient components for ten boards plus the assembler's required attrition; visible stock is not a reservation. C1/L1 and the ten-piece F6 supply need particular attention. F6 is hand-inserted and has no spare allowance in the observed stock.

JLC library parts are PCBA-only and are not shipped separately. Hand-fitting authorization does not arrange delivery of loose catalogue parts. Obtain an explicit assembler supply/installation arrangement or source manual/harness items separately. This remains unresolved and prevents describing the whole package as ready to order without conditions. No hardware testing or manufacturing quote is claimed.
