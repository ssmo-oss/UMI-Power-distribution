# D4 manual assembly and harness parts

The batch is **ten MAIN_POWER and ten USB_POWER boards**, forming ten systems. Use each board's BOM_by_reference.csv for board-mounted through-hole parts. MANUAL_FUSES_AND_HARNESS_BOM.csv adds inserts and cable-side parts; do not count holders as inserts.

| Position | Insert | Rating | JLC reference | Installed quantity for ten systems |
|---|---|---|---|---:|
| Main F1/F2 | Littelfuse 028707.5PXCN | 7.5 A, 32 V DC | C142688 | 20 |
| Main F3 | Littelfuse 0287001.PXCN | 1 A, 32 V DC | C142679 | 10 |
| Main F4 | Littelfuse 0287005.PXCN | 5 A, 32 V DC | C142682 | 10 |
| Main F5 | Littelfuse 0287010.PXCN | 10 A, 32 V DC | C142683 | 10 |
| Main F6 | Littelfuse 166.7000.4302 | 3 A, 80 V DC | C3662004 | 10 |

All six holders are Littelfuse **178.6165.0002**, JLC C207061: sixty installed holders. The final suffix changes bulk pack size only; holder geometry and 80 V rating are unchanged. The 287-series 32 V inserts retain standard ATO fit and 1 kA breaking rating. The FKS 80 V insert retains the compatible ATO/FKS format and 1 kA breaking rating. Never substitute a 32 V insert on the 53.5 V switch output.

F6's observed stock was exactly ten pieces: enough for the ten hand-inserted boards, with **no spare allowance**. Stock was not reserved. Distributor lifecycle warnings were found, but current manufacturer obsolescence was not established; do not represent this as an officially confirmed lifecycle status. Final procurement must confirm ten deliverable exact pieces.

JLC parts-library stock is for PCBA use and cannot simply be shipped loose. The listed codes do not mean loose fuse inserts, holders or harness parts will arrive with the boards. Agree how the assembler will supply/install these items, or source manual parts separately. The manual/harness supply arrangement remains pending.

Main board thickness remains 1.2 mm, below the holder's 1.5 mm limit. USB remains 1.6 mm. The JST header drawing uses 1.6 mm PCB; verify seating, retention and excess lead protrusion on the thinner main board. Input terminal J1 retains Phoenix 1709681, requiring exact-part procurement/preorder confirmation; no alternate terminal footprint was adopted.

Cable housings for main J2–J5 and USB J1 change to **JST VHR-2N-BK**, a black colour variant of VHR-2N with unchanged mating geometry: fifty housings for ten systems. Main switch connector uses VHR-3N, with contacts only in positions1 and3; position2 remains empty. Confirm pin1 positive and return using final numbered pads and the pin schedule before terminating any harness.

JST SVH-41T-P1.1 accepts AWG20–16 with the specified insulation diameter. For thinner fan wires use the compatible SVH-21T-P1.1 (AWG22–18) and adjust counts. Use appropriate crimp tooling and retention/pull checks; do not tin conductors before crimping. Housing/terminal catalogue availability is not a completed cable assembly.

Installed quantities exclude spares, purchasing pack multiples, device-end plugs, supply-input cable, mounting hardware and enclosure-specific lengths. Interboard cable length remains provisional; verify it in the enclosure. Provide upstream cable protection appropriate to the actual supply-input wire and installation. Branch fuses do not protect a short before the PCB.

The manufacturer time-current curves and typical temperature derating support the selected ratings, but nuisance-opening, contact-temperature and startup checks remain required at40 °C. Fuse clearing alone does not establish semiconductor short-circuit survival. No physical bring-up or thermal tests have been performed by the software agent.

Sources: [Littelfuse287 ATOF](https://www.littelfuse.com/assetdocs/littelfuse-datasheet-287-atof?assetguid=43dcdce8-8ca2-426f-8998-7e566f048d40), [LittelfuseFKS80 manufacturer-sheet mirror](https://xonstorage.z8.web.core.windows.net/pdf/littelfuse_16670004402_apr22_xonlink.pdf), [FLR holder manufacturer-sheet mirror](https://datasheet.octopart.com/178.6165.0001-Littelfuse-datasheet-8836287.pdf), [JST VH](https://www.jst-mfg.com/product/pdf/eng/eVH.pdf).
