# UMI two-board design — D4 procurement prototype

Updated 26 September 2026 for **10 MAIN_POWER and 10 USB_POWER boards**. Open `MAIN_POWER/MAIN_POWER.kicad_pro` and `USB_POWER/USB_POWER.kicad_pro`. D4 contains actual schematic and PCB changes, not only a sourcing spreadsheet. D3 is preserved separately.

## Changes applied

- Main MOSFETs, current-sense resistor, auxiliary inductor, diode, selected capacitors and resistors now use reviewed JLC-listed replacements. The current-sense resistor uses the manufacturer's recommended solder lands.
- R20 changes from 931 ohms to 953 ohms, both 0.1%, to resolve the stock shortage. Calculated boost output changes from 53.5047 V to 53.5182 V; the static tolerance estimate is 52.8795–54.1591 V before ripple and transients.
- USB input capacitors have their complete orderable TDK part number. The 15.8 kohm timing resistor changes to an equivalent Panasonic part with accessible stock.
- Fuse holders use the same physical holder in a stocked packaging variant. All six fuses remain; the manual list specifies compatible Littelfuse inserts with unchanged current ratings. The two-position harness housing changes only in colour, to black.
- The D3 board outlines, holes, component positions and routing are retained. Copper changes are local to the revised shunt lands and the resulting zone refill. Revision legends now say D4.

`PROCUREMENT_CHANGES.json` records applied board-part changes. The **single combined list** is `UMI_COMPONENT_SOURCING.xlsx` (also CSV), covering both boards, hand-fit parts, inserts and the specified harness components. The list distinguishes applied substitutions from unresolved purchasing conditions.

## Validation

Both saved boards pass native KiCad DRC with zero reported violations, unconnected items and schematic-parity issues. Both schematics pass ERC with zero reported violations under the included project settings. Reports disclose disabled optional check categories. Independent Gerber/drill checks match all 133 main-board and 137 USB-board holes and all 53/31 SMT placement centres. BOM, schematic, PCB and design-record identities are checked together. Corrected supplier placement rotations include an independent proof for the new shunt footprint.

Gerbers, drills, top paste, schematics, editable local libraries, review drawings and BOM/CPL files have been regenerated from D4. View `LAYOUT_REVIEW.html` and the per-board review folders.

## Ordering status — procurement and assembly hold

The design files are prepared for prototype quoting, **not an unconditional ready-to-order release**:

1. Main R1, Panasonic ERJ-12ZYJ7R5U / C2086794, is JLC preorder only. The observed minimum is 734 pieces, estimated total USD 8.66; lead time was not displayed. This retains the original snubber part rather than an unverified substitution.
2. Main J1, Phoenix 1709681 / C5872886, is JLC preorder only. Observed minimum 2, estimated USD 4.9074 each; ten are needed and lead time is unconfirmed. Its high-current four-pin footprint is retained.
3. The 80 V / 3 A output fuse, 166.7000.4302 / C3662004, has exactly ten displayed pieces against ten required, with no spare margin. Main C1 and L1 also have limited stock. Quantities are snapshots, not reservations; assembler attrition is additional.
4. JLC assembly-library components cannot be shipped separately. Hand-fit parts, fuse inserts and harness components therefore require an agreed assembly/supply arrangement or separate loose-component procurement. A JLC catalogue code does not resolve this requirement.
5. The supplier must accept the specified stackups, filled/capped vias, heavy-inductor support, component orientation and placement preview. No quote, inventory reservation, upload or purchase has been made.

All current component groups have JLC catalogue codes, but this is not a claim that every part is immediately orderable or supplied loose. Refer to the combined list for the dated evidence and quantities for ten pairs.

## Manufacturing and assembly files

Each board's `*_GERBERS.zip` is its matched fabrication set. Apply `MANUFACTURING_SPECIFICATION.md`: both are four-layer boards with 2 oz outer / 1 oz inner copper and filled/capped vias; MAIN_POWER is 1.2 mm thick and USB_POWER 1.6 mm.

For SMT quoting use `BOM_JLC_DRAFT.csv` with `assembly/*_CPL_JLC.csv` and top paste. Raw `*_positions.csv` is a reference export, not the corrected supplier placement file. The combined workbook remains the master purchasing overview; per-board import files are generated subsets required for quoting.

No hardware has been fabricated or load-tested. Follow `ENGINEERING_AND_TEST_NOTES.md` for current-limited bring-up, switching/thermal checks at 40 °C and load/fault tests. USB-A charging identification does not guarantee the unspecified headset will draw 3 A. Actual cable length and device-end plugs remain to be finalized.
