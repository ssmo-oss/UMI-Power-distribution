# UMI PDB Rev C — six-output 12 V / 5 V board

**ENGINEERING HOLD — fabrication and assembly previews are not an order release.**

## PCBA assembly files and populated-board view

- `assembly_bom_REVIEW_ONLY.csv`: manufacturer parts and identified JLC/LCSC IDs.
- `component_positions.csv`: KiCad placement/CPL export for top and bottom parts.
- `populated_board_top_PREVIEW.png` and `.pdf`: component-envelope drawings of the populated top side. The actual small SMD parts are on the underside. These drawings do not certify enclosure clearance or exact 3D shapes.
- `generate_assembly_view.py`: reproducible drawing generator.

These are **review materials**, not a ready-to-submit JLCPCB turnkey PCBA package. J1 and U1 lack confirmed assembly sourcing, and their mechanical/thermal release checks remain open. Blade fuses themselves must also be specified and supplied separately from their holders.
The DXF-shaped KiCad board is routed and filled. The KiCad 7 DRC report has
zero violations and zero unconnected pads. Electrical design review,
supplier sourcing, and a first-article thermal/functional test remain open.
The project has a board and connection schedule but no linked KiCad schematic;
there is therefore no schematic ERC or schematic-to-board comparison.

## Functional configuration

| Board reference | Branch | Maximum continuous load | Proposed ATO blade fuse |
|---|---|---:|---:|
| F1 / J2 | Extra 12 V | 5 A | 7.5 A |
| F2 / J3 | Jetson Orin Nano 12 V | 5 A | 7.5 A |
| F3 / J4 | SG4A 12 V, **assumption** | 3 A | 5 A |
| F4 / J5 | 5 V A | 3 A | 5 A |
| F5 / J6 | 5 V B | 3 A | 5 A |
| F6 / J7 | 5 V C | 3 A | 5 A |

All six outputs retain the Littelfuse 178.6165.0001 ATO blade fuse holder
and JST B2P-VH(LF)(SN) two-position connector. Every output header has pin 1
positive and pin 2 ground. The fuse inserts are separate consumables. For
the 5 A harnesses, use a suitable JST VHR-2N housing and manufacturer
approved AWG16 crimp contact; confirm wire derating, length and voltage drop.

The original configuration's two other Extra 12 V outputs, the Ethernet
switch and the Ethernet-powered ESP modules are absent. The 12 V fan listed
in the component PDF remains absent because it was absent from the original
schematic. The source PDF lists SG4A as `12A/3A`; the circuit assumes **12 V
/ 3 A**, which requires confirmation before assembly.

## Supply and conversion

The three 12 V branches total 13 A / 156 W. Three simultaneous 5 V / 3 A
branches require 45 W output. At a conservative 90% conversion efficiency,
the complete board draws approximately **206 W / 17.17 A from the 12 V
source**. The RSP-320-12 supply is rated 320.4 W / 26.7 A, leaving about
114 W / 9.53 A at the rating, before environmental derating or other loads.

The input is a Phoenix Contact 1709681 two-position screw PCB terminal,
specified at 76 A and accepting AWG8 stranded wire with correctly sized
ferrules. Specify 1.2–1.5 N·m screw torque per manufacturer. The DC/DC is
Murata OKR-T/10-W12-C, with pin 1 left open (standard enabled configuration),
pin 2 12 V, pin 3 ground, pin 4 5 V and pin 5 trim. A 267 ohm, 0.1%, 25 ppm/°C,
0.1 W resistor from trim to ground gives **nominal 5.018 V** by the Murata
equation. There are two nominal 22 µF / 25 V input ceramics and 1 µF plus
10 µF output ceramics. Effective capacitance under DC bias must be checked.

The converter is rated 10 A and the loads total 9 A. Its temperature
derating at 12 V input, 5 V output and the actual backpack airflow must be
verified. A 5 A blade fuse on a 5 V branch does not guarantee selective
fault isolation before the converter enters current limit. A JST two-wire
output also does not implement USB-C CC current advertisement or USB PD:
build and verify the device-specific USB-C adapter/harness separately.

## Mechanics, layers and files

- Original DXF geometry: 68 × 100.263962 mm overall; twelve R5 arcs
  approximated in the edge layer with 16 chords each (maximum error about
  0.0061 mm). Four 4.5 mm nonplated mounting holes are at DXF centres
  (17, ±42.131981) and (69, ±42.131981) mm. Repeated DXF entities were
  deduplicated. Confirm the extra R4.5 circle at one mounting hole denotes
  a standoff or washer keepout before installation.
- Four copper layers, 1.2 mm nominal PCB. Front carries short fused output
  routes, inner 1 is the 12 V bus, inner 2 is ground and rear is the 5 V bus
  plus small components. Request **1 oz finished inner copper** and confirm
  JLCPCB can supply that stackup at 1.2 mm, then check plane neck current
  density, copper temperature rise and voltage drop at 17.2 A.
- `UMI_PDB_revC_6OUT.kicad_pcb` is the editable, filled PCB. The footprint
  libraries are included with a local `fp-lib-table`. Original DXF, previous
  DXF-only KiCad board and reproducible build scripts are included.
- `assembly_bom_REVIEW_ONLY.csv` maps manufacturer parts and identified
  JLC/LCSC numbers. It is **not** a completed turnkey assembly BOM: the input
  screw terminal and converter have no confirmed JLC stock/assembly IDs.
- `component_positions.csv` is KiCad's native position export. Its Y values
  use KiCad's plot convention; review placement and rotation in JLC's upload
  preview before any released production order.
- `fab_preview/` contains filled Gerbers and drill data for inspection only.

## Required before ordering a PCBA

1. Confirm terminal and Murata module CAD land patterns against manufacturer
   mechanical CAD, especially the terminal's four zigzag pins, wire-entry
   direction and mounting washer clearances. The current patterns were
   transcribed from published drawings rather than checked against samples.
2. Complete and review a linked schematic. Confirm SG4A voltage, fuse
   cartridges and time/current curves, supply overload behaviour, reverse
   polarity risk and harness/USB-C pinout.
3. Confirm JLCPCB can source/assemble 1709681 and OKR-T/10-W12-C and
   install the six fuse cartridges, and verify other parts are stocked when
   ordering. Vendor listings for the holder and JST header indicate THT
   assembly support, but those listings are not a complete order approval.
4. Confirm 1 oz inner copper on a 1.2 mm board, build a first article and
   measure input/return drop, all six loaded output voltages, transient
   response, fuse-holder and terminal temperatures, and 9 A buck heating in
   the backpack at the highest intended ambient temperature.

Manufacturer information:

- Phoenix 1709681: https://www.phoenixcontact.com/en-pc/products/pcb-terminal-block-mkds-10-hv-2-zb-1016-1709681
- Murata OKR-T/10-W12-C: https://www.murata.com/products/productdata/8807038484510/okr-t10-w12.pdf
- Littelfuse 178.6165.0001: https://www.littelfuse.com/assetdocs/ato-flr-datasheet?assetguid=bef6771d-7ae2-4b18-8f55-8cde6402100a
- JST VH: https://www.jst-mfg.com/product/pdf/eng/eVH.pdf
- RSP-320-12: https://www.meanwell.com/Upload/PDF/RSP-320/RSP-320-SPEC.PDF
