#!/usr/bin/python3
"""Electrically connected, pre-release 6-output DXF PDB layout."""
import pcbnew as p
from pathlib import Path
from collections import Counter
import shutil

OUT=Path('.')
OUT.mkdir(exist_ok=True)
board=p.LoadBoard('UMI_PDB_revB_DXF_mechanics.kicad_pcb')
board.SetCopperLayerCount(4)
board.GetDesignSettings().SetBoardThickness(p.FromMM(1.2))
# Remove the mechanics-only warning from the middle of the electrical layout.
for item in list(board.GetDrawings()):
 if isinstance(item,p.PCB_TEXT) and 'MECHANICAL ONLY' in item.GetText():
  board.Remove(item)
mm=p.FromMM
V=lambda x,y:p.VECTOR2I(mm(x),mm(y))

def net(name):
 n=p.NETINFO_ITEM(board,name);board.Add(n);return n
vin=net('+12V_IN'); ground=net('GND'); bus5=net('+5V_BUS'); trim=net('TRIM')
outputs=[net('+12V_EXTRA'),net('+12V_JETSON'),net('+12V_SG4A'),
         net('+5V_A'),net('+5V_B'),net('+5V_C')]

def load(lib,name,ref,value,x,y):
 fp=p.FootprintLoad('/usr/share/kicad/footprints/'+lib+'.pretty',name)
 assert fp,(lib,name)
 fp.SetReference(ref);fp.SetValue(value);fp.SetPosition(V(x,y))
 fp.SetFPID(p.LIB_ID(lib,name))
 fp.Value().SetVisible(False);board.Add(fp)
 fp.Reference().SetVisible(False)
 return fp

def custom(ref,value,x,y,description,pads,bounds):
 fp=p.FOOTPRINT(board);fp.SetReference(ref);fp.SetValue(value)
 fp.SetPosition(V(x,y));fp.SetFPID(p.LIB_ID('UMI_Custom',description))
 for name,px,py,nt,drill,diam in pads:
  pad=p.PAD(fp);pad.SetName(str(name));pad.SetAttribute(p.PAD_ATTRIB_PTH)
  pad.SetShape(p.PAD_SHAPE_CIRCLE);pad.SetSize(V(diam,diam))
  pad.SetDrillSize(V(drill,drill));pad.SetPos0(V(px,py))
  pad.SetLayerSet(p.LSET.AllCuMask());pad.SetNet(nt);fp.Add(pad)
 a,b,c,d=bounds
 for (u,v),(w,z) in [((a,b),(c,b)),((c,b),(c,d)),((c,d),(a,d)),((a,d),(a,b))]:
  s=p.FP_SHAPE(fp);s.SetShape(p.SHAPE_T_SEGMENT);s.SetStart0(V(u,v));s.SetEnd0(V(w,z))
  s.SetLayer(p.F_CrtYd);s.SetWidth(mm(.05));fp.Add(s)
 board.Add(fp);fp.Value().SetVisible(False)
 fp.Reference().SetVisible(False)
 return fp

# Phoenix 1709681; dimensions transcribed from the manufacturer's 2025 drawing.
# Four Ø1.5 mm PTH holes, two solder pins for each potential, zigzag W layout.
custom('J1','Phoenix 1709681 / INPUT AWG8 FERRULE',39,23,'Phoenix_1709681',[
 ('1',3.08,3,vin,1.5,3.2),('1',7.08,3,vin,1.5,3.2),
 ('2',13.24,13.16,ground,1.5,3.2),('2',17.24,13.16,ground,1.5,3.2)],
 (0,0,20.32,18.7))

placements=[(17,45,21,55),(50,45,54,55),(17,63,21,73),
            (50,63,54,73),(17,81,21,91),(50,81,54,91)]
labels=['EXTRA 12V 5A','JETSON 12V 5A','SG4A 12V 3A',
        '5V A 3A','5V B 3A','5V C 3A']
for idx,(fx,fy,jx,jy) in enumerate(placements):
 n=outputs[idx]
 fuse=load('Fuse','FuseHolder_Blade_ATO_Littelfuse_FLR_178.6165',
           f'F{idx+1}',('5A ATO' if idx>=3 or idx==2 else '7.5A ATO'),fx,fy)
 for pad in fuse.Pads():
  if pad.GetNumber()=='1':pad.SetNet(vin if idx<3 else bus5)
  elif pad.GetNumber()=='2':pad.SetNet(n)
 con=load('Connector_JST','JST_VH_B2P-VH_1x02_P3.96mm_Vertical',
          f'J{idx+2}',labels[idx],jx,jy)
 for pad in con.Pads():pad.SetNet(n if pad.GetNumber()=='1' else ground)

def trace(nt,points,width,layer=p.F_Cu):
 for a,b in zip(points,points[1:]):
  t=p.PCB_TRACK(board);t.SetStart(V(*a));t.SetEnd(V(*b))
  t.SetWidth(mm(width));t.SetLayer(layer);t.SetNet(nt);board.Add(t)

for idx,(fx,fy,jx,jy) in enumerate(placements):
 # From fuse output pad 2, around the empty fuse-holder slot to header pin 1.
 trace(outputs[idx],[(fx+9.3,fy),(fx+9.3,fy+6),(jx,jy-4),(jx,jy)],2.1)
 # Each fuse clip has four physical mounting pins numbered as one net. Tie
 # them together on copper so electrical continuity does not depend on the
 # clip body's mechanical contact with the solder joints.
 trace(outputs[idx],[(fx+9.3,fy),(fx+12.8,fy),
                     (fx+12.8,fy+2.5),(fx+9.3,fy+2.5)],1.4)

# Five-lead Murata OKR-T/10-W12-C module, P73 pinout and 2.54-mm pitch.
custom('U1','Murata OKR-T/10-W12-C / 5V 10A',40,80,'Murata_OKR_T10_W12_C',[
 ('1',0,0,None,1.1,1.9),('2',0,2.54,vin,1.1,1.9),
 ('3',0,5.08,ground,1.1,1.9),('4',0,7.62,bus5,1.1,1.9),
 ('5',0,10.16,trim,1.1,1.9)],(-5.2,-3.17,5.2,13.33))

# 267 ohms yields nominal 5.018 V from Murata's specified trim formula.
# Precision metal film, 0.1%, 25 ppm/C, 0.1 W minimum.
r=load('Resistor_SMD','R_0603_1608Metric','R1','267R 0.1%',40,96)
def set_backside(fp):
 fp.SetLayer(p.B_Cu)
 for obj in fp.GraphicalItems():
  l=obj.GetLayer()
  if l==p.F_SilkS:obj.SetLayer(p.B_SilkS)
  elif l==p.F_Fab:obj.SetLayer(p.B_Fab)
  elif l==p.F_CrtYd:obj.SetLayer(p.B_CrtYd)
 fp.Reference().SetLayer(p.B_SilkS)
 fp.Value().SetLayer(p.B_Fab)

set_backside(r)
bottom=p.LSET()
for layer in (p.B_Cu,p.B_Paste,p.B_Mask):bottom.AddLayer(layer)
for pad in r.Pads():pad.SetLayerSet(bottom)
for pad in r.Pads():pad.SetNet(trim if pad.GetNumber()=='1' else ground)

def via(nt,x,y):
 q=p.PCB_VIA(board);q.SetPosition(V(x,y));q.SetWidth(mm(.85));q.SetDrill(mm(.4))
 q.SetViaType(p.VIATYPE_THROUGH);q.SetLayerPair(p.F_Cu,p.B_Cu)
 q.SetNet(nt);board.Add(q)

trace(trim,[(40,90.16),(38,92),(38,96),(39.175,96)],.35,p.B_Cu)
trace(ground,[(40.825,96),(42.5,96)],.45,p.B_Cu)
via(ground,42.5,96)

# Backside input bypass, and paired 1uF/10uF converter output bypass.
# Capacitor pad 1 is the power rail and pad 2 returns via the ground plane.
for ref,value,name,x,y,nt in [
 ('C1','22uF 25V X7R','C_1210_3225Metric',37,72,vin),
 ('C2','22uF 25V X7R','C_1210_3225Metric',45,72,vin),
 ('C3','1uF 10V X7R','C_0805_2012Metric',40,75,bus5),
 ('C4','10uF 10V X7R','C_1206_3216Metric',47,96,bus5)]:
 cap=load('Capacitor_SMD',name,ref,value,x,y)
 set_backside(cap)
 for pad in cap.Pads():pad.SetLayerSet(bottom)
 padmap={pad.GetNumber():pad for pad in cap.Pads()}
 for n,pad in padmap.items():pad.SetNet(nt if n=='1' else ground)
 for n,pad in padmap.items():
  px,py=p.ToMM(pad.GetPosition().x),p.ToMM(pad.GetPosition().y)
  vx=px+(-1.3 if n=='1' else 1.3)
  trace(nt if n=='1' else ground,[(px,py),(vx,py)],.4,p.B_Cu)
  # Input capacitors connect to the buried 12 V plane, output capacitors
  # directly connect to the back-side 5 V plane. All GNDs need vias.
  if n=='2' or nt==vin:via(nt if n=='1' else ground,vx,py)

def plane(nt,layer):
 z=p.ZONE(board);z.SetLayer(layer);z.SetNet(nt)
 z.SetLocalClearance(mm(.35));z.SetPadConnection(p.ZONE_CONNECTION_FULL)
 z.SetThermalReliefGap(mm(.5));z.SetThermalReliefSpokeWidth(mm(.7))
 poly=z.Outline();poly.NewOutline()
 for point in [(10.3,10.3),(77.7,10.3),(77.7,109.9),(10.3,109.9)]:
  poly.Append(*[mm(x) for x in point])
 board.Add(z)

plane(vin,p.In1_Cu)
plane(ground,p.In2_Cu)
plane(bus5,p.B_Cu)

# Useful durable notes in the actual board file, away from board edges.
def label(value,x,y,layer=p.F_SilkS):
 t=p.PCB_TEXT(board);t.SetText(value);t.SetPosition(V(x,y))
 t.SetTextSize(V(.95,.95));t.SetTextThickness(mm(.15))
 t.SetLayer(layer);board.Add(t)
label('12V INPUT  + / -',69,30)
label('+',35,27)
label('-',64,36)
for i,(fx,fy,jx,jy) in enumerate(placements):
 short=['EXTRA','JETSON','SG4A','5V A','5V B','5V C'][i]
 label(short,38 if i in (0,2) else 32 if i==4 else 70,jy)
label('REV C / 4 LAYER / HOLD',39,54,p.B_SilkS)

path=OUT/'UMI_PDB_revC_6OUT.kicad_pcb'
p.SaveBoard(str(path),board)
custom_dir=OUT/'UMI_Custom.pretty'
custom_dir.mkdir(exist_ok=True)
for fp in board.GetFootprints():
 if fp.GetReference() in ('J1','U1'):
  p.FootprintSave(str(custom_dir),fp)
(OUT/'fp-lib-table').write_text('''(fp_lib_table
  (lib (name "Fuse") (type "KiCad") (uri "${KIPRJMOD}/Fuse.pretty") (options "") (descr ""))
  (lib (name "Connector_JST") (type "KiCad") (uri "${KIPRJMOD}/Connector_JST.pretty") (options "") (descr ""))
  (lib (name "MountingHole") (type "KiCad") (uri "${KIPRJMOD}/MountingHole.pretty") (options "") (descr ""))
  (lib (name "Capacitor_SMD") (type "KiCad") (uri "${KIPRJMOD}/Capacitor_SMD.pretty") (options "") (descr ""))
  (lib (name "Resistor_SMD") (type "KiCad") (uri "${KIPRJMOD}/Resistor_SMD.pretty") (options "") (descr ""))
  (lib (name "UMI_Custom") (type "KiCad") (uri "${KIPRJMOD}/UMI_Custom.pretty") (options "") (descr ""))
)\n''')
for lib,names in {
 'Fuse':['FuseHolder_Blade_ATO_Littelfuse_FLR_178.6165'],
 'Connector_JST':['JST_VH_B2P-VH_1x02_P3.96mm_Vertical'],
 'MountingHole':['MountingHole_4.5mm'],
 'Capacitor_SMD':['C_1210_3225Metric','C_0805_2012Metric','C_1206_3216Metric'],
 'Resistor_SMD':['R_0603_1608Metric']}.items():
 dest=OUT/(lib+'.pretty');dest.mkdir(exist_ok=True)
 for name in names:
  shutil.copy2(Path('/usr/share/kicad/footprints')/(lib+'.pretty')/(name+'.kicad_mod'),dest)
for fp in board.GetFootprints():
 if fp.GetReference().startswith(('C','R','H')):
  nickname=str(fp.GetFPID().GetLibNickname())
  if nickname:
   p.FootprintSave(str(OUT/(nickname+'.pretty')),fp)
shutil.copy2('/usr/share/doc/kicad-footprints/copyright',OUT/'KICAD_FOOTPRINTS_COPYRIGHT')
print('Saved',path,'footprints',len(list(board.GetFootprints())),
      'zones',len(board.Zones()),'tracks',len(board.GetTracks()))
