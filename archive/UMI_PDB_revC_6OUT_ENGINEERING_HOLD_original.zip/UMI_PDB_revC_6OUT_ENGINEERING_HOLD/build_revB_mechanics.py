#!/usr/bin/env python3
"""Derive the revision B KiCad board edge and mounting holes from the user DXF."""
import math
from pathlib import Path
import ezdxf

source = Path('upload/10052149_AA-UMI PACK PDB FOOTPRINT_1.dxf')
out = Path('UMI_PDB_revB_DXF_ENGINEERING_HOLD')
out.mkdir(exist_ok=True)
doc = ezdxf.readfile(source)
assert doc.header['$INSUNITS'] == 4, 'DXF must have millimetre units'
xy = lambda x, y: (x - 9 + 10, 50.131981 - y + 10)
edges = set()
holes = set()
shapes = []

def add_segment(a, b):
    key = tuple(sorted(((round(a[0], 5), round(a[1], 5)),
                        (round(b[0], 5), round(b[1], 5)))))
    if key in edges:
        return
    edges.add(key)
    x1,y1=xy(*a)
    x2,y2=xy(*b)
    shapes.append(f'  (gr_line (start {x1:.6f} {y1:.6f}) '
                  f'(end {x2:.6f} {y2:.6f}) (layer "Edge.Cuts") (width 0.05))')

for entity in doc.modelspace():
    typ = entity.dxftype()
    d = entity.dxf
    if typ == 'LINE':
        add_segment((d.start.x, d.start.y), (d.end.x, d.end.y))
    elif typ == 'ARC':
        # The short arcs are the designed R5 board notches. Chord error < 0.006 mm.
        start = d.start_angle
        sweep = (d.end_angle - start) % 360
        assert sweep == 90 and abs(d.radius - 5) < 1e-6
        points = []
        for k in range(17):
            t = math.radians(start + sweep*k/16)
            points.append((d.center.x+d.radius*math.cos(t),
                           d.center.y+d.radius*math.sin(t)))
        for a, b in zip(points, points[1:]):
            add_segment(a, b)
    elif typ == 'CIRCLE' and abs(d.radius - 2.25) < 1e-6:
        holes.add((round(d.center.x, 6), round(d.center.y, 6)))

assert len(holes) == 4 and len(edges) == 200, (len(holes), len(edges))
for i, (x, y) in enumerate(sorted(holes), 1):
    px,py=xy(x,y)
    shapes.append(f'''  (footprint "MountingHole:MountingHole_4.5mm"
    (layer "F.Cu") (at {px:.6f} {py:.6f})
    (attr exclude_from_pos_files exclude_from_bom)
    (fp_text reference "H{i}" (at 0 -3) (layer "F.SilkS")
      (effects (font (size 1 1) (thickness 0.15))))
    (fp_text value "DXF 4.5mm NPTH" (at 0 3) (layer "F.Fab") hide
      (effects (font (size 1 1) (thickness 0.15))))
    (pad "" np_thru_hole circle (at 0 0) (size 4.5 4.5)
      (drill 4.5) (layers "*.Cu" "*.Mask"))
  )''')

header='''(kicad_pcb (version 20221018) (generator pcbnew)
  (general (thickness 1.6))
  (paper "A4")
  (layers (0 "F.Cu" signal) (31 "B.Cu" signal)
          (36 "B.SilkS" user) (37 "F.SilkS" user)
          (38 "B.Mask" user) (39 "F.Mask" user)
          (44 "Edge.Cuts" user) (49 "F.Fab" user))
  (setup (pad_to_mask_clearance 0))
  (net 0 "")
'''
content=(header+'\n'.join(shapes)+'''
  (gr_text "UMI PDB REV B / MECHANICAL ONLY / ENGINEERING HOLD"
    (at 44 60) (layer "F.SilkS")
    (effects (font (size 1.1 1.1) (thickness 0.15))))
)\n''')
(out/'UMI_PDB_revB_DXF_mechanics.kicad_pcb').write_text(content)
print('Unique board edge segments:',len(edges),'mounting holes:',len(holes))
print('Saved:',out/'UMI_PDB_revB_DXF_mechanics.kicad_pcb')
