"""Create a component-envelope preview from the KiCad placement export.

This illustrates populated component positions, not verified mechanical 3D models.
"""
import csv
from pathlib import Path
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, Circle, FancyBboxPatch

HERE = Path(__file__).resolve().parent
with (HERE / 'component_positions.csv').open(newline='') as f:
    parts = {r['Ref']: (float(r['PosX']), -float(r['PosY'])) for r in csv.DictReader(f)}

fig, ax = plt.subplots(figsize=(9, 13), dpi=180)
fig.patch.set_facecolor('#f7f8f7')
image = plt.imread(HERE / 'layout.png')
ax.imshow(image, extent=(10, 78, 110.264, 10), interpolation='bilinear', alpha=.46)

def box(x, y, w, h, color, edge='#25342c', radius=.7, z=3):
    ax.add_patch(FancyBboxPatch((x, y), w, h,
        boxstyle=f'round,pad=0,rounding_size={radius}',
        facecolor=color, edgecolor=edge, linewidth=1.15, zorder=z))

def label(x, y, s, size=7.4, color='#142925', weight='bold', z=8):
    ax.text(x, y, s, ha='center', va='center', fontsize=size,
            color=color, fontweight=weight, zorder=z)

# Input terminal block: housing envelope and illustrative screw positions.
x, y = parts['J1']
box(x, y, 20.32, 18.7, '#299054', '#1f5637', 1.0)
for sx, sy in [(x+5.1,y+7.2),(x+15.2,y+7.2)]:
    ax.add_patch(Circle((sx,sy), 2.45, facecolor='#c5ced1', edgecolor='#40535b', zorder=5))
    ax.plot([sx-1.1,sx+1.1],[sy,sy], color='#53656b', lw=1.3, zorder=6)
label(x+10.16,y+14.2,'12V INPUT',7.3,'white')
label(x+10.16,y-2.1,'J1  •  SCREW TERMINAL',7.5)

branches = [('F1','J2','EXTRA 12V / 5A'),('F2','J3','JETSON 12V / 5A'),
            ('F3','J4','SG4A 12V / 3A*'),('F4','J5','5V A / 3A'),
            ('F5','J6','5V B / 3A'),('F6','J7','5V C / 3A')]
for fuse, connector, name in branches:
    fx,fy=parts[fuse]; jx,jy=parts[connector]
    box(fx-4.15,fy-2.25,21.1,7.05,'#242a2c','#101819',.45)
    box(fx+.65,fy-.58,11.2,3.75,'#97613b' if fuse in ('F1','F2') else '#bb9a68',
        '#5b5143',.25,4)
    label(fx+6.15,fy+1.25,'7.5A' if fuse in ('F1','F2') else '5A',6.5,'#fff8e7',z=7)
    box(jx-2.95,jy-4.25,9.4,9.55,'#f4f4e9','#697875',.55)
    for px in [jx+.9,jx+4.7]:
        box(px-1.0,jy-1.35,2.2,3.3,'#363c3c','#747a77',.25,4)
    label(jx+1.8,jy+3.65,connector,6.8)
    label(fx-1.8,fy+1.25,fuse,6.5,'white')

ux,uy=parts['U1']
box(ux-5.2,uy-3.2,10.4,16.5,'#244d72','#112c4e',.35)
label(ux,uy+3.5,'U1',8.5,'white')
label(ux,uy+7.0,'5V / 10A',6.5,'white')

ax.set_xlim(6,82); ax.set_ylim(117,5); ax.set_aspect('equal')
ax.axis('off')
ax.set_title('UMI PDB Rev C  |  populated top-side placement preview',
             fontsize=14, loc='left', weight='bold', pad=12)
fig.text(.10,.065,'Mounting holes and board edge follow the supplied DXF. Small capacitors and resistor are on the underside.',fontsize=8)
fig.text(.10,.046,'* SG4A input rating needs confirmation. Component bodies are illustrative envelopes, not validated 3D models.',fontsize=8)
fig.text(.10,.027,'ENGINEERING HOLD  •  BOM and placement are review files; J1 and U1 assembly sourcing remains open.',
         fontsize=8,color='#a3352d',weight='bold')
fig.subplots_adjust(top=.92,bottom=.10,left=.08,right=.95)
fig.savefig(HERE / 'populated_board_top_PREVIEW.png',dpi=180,facecolor=fig.get_facecolor())
fig.savefig(HERE / 'populated_board_top_PREVIEW.pdf',facecolor=fig.get_facecolor())
