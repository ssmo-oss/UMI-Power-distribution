# UMI USB D1 — linked placement draft

**WITHDRAWN FROM FABRICATION CONSIDERATION:** the inherited Murata footprint has 2.54 mm pin pitch; the manufacturer drawing specifies 1.7 mm. Its board-plane body dimensions also need correction, and the converter is obsolete. The text connectivity checks below did not verify physical pin locations. Do not order this revision. See ../ORDER_RELEASE_STATUS.md.

Open UMI_USB_D1.kicad_pro in KiCad, then its schematic or PCB. Local footprint library is included.

This is an editable 60 × 30 mm placement draft, not a manufacturing release. There are 20 linked components, named pad nets and no routed copper. Two provisional USB-A ports face the same long edge. Input and converter occupy the opposite side of the board.

Changes: added all draft support components to PCB; linked each footprint to its schematic symbol; corrected USB shield numbering to SH; restored missing solder-mask openings on inherited converter pads; bundled footprints.

Checks performed: text structure round-trip; every scheduled pin has a matching footprint pad and net; symbol paths assigned. KiCad loading, ERC, DRC and 3D inspection have NOT been performed. Custom review symbols still use passive pin types and do not provide meaningful electrical-rule checking.

Open engineering items before routing/release: verify 3 A USB-A connector selection and exact mechanical drawing; validate inherited Murata footprint and trim against manufacturer drawing; settle input fault protection and port ESD; check capacitor effective capacitance, switch thermal design and full-load voltage drop; confirm enclosure/mounting/height; choose copper stackup and routing; run KiCad ERC/DRC and prototype load/short-circuit/thermal tests. No mounting holes are assumed.

The TPS2557 pinout was checked against https://www.ti.com/lit/ds/symlink/tps2557.pdf . Charging-controller reference: https://www.ti.com/lit/ds/symlink/tps2513a.pdf . Neither source establishes that the connected headset will draw 3 A from USB-A.

No KiCad executable or KiCad-bundled Python was launched to create this package.
