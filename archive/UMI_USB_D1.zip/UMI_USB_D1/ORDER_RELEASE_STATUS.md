# UMI two-board manufacturing release status

Status: NOT READY TO ORDER. No revision in this folder is a manufacturing release.

## Confirmed requirements, 25 September 2026

- Main PCB: original DXF outline and all original mounting-hole locations remain exact.
- USB PCB: 60 x 30 mm.
- Maximum enclosure ambient: 40 degrees C.
- SMT assembly is intended; user will fit through-hole parts, connectors and fuses.
- Input: Mean Well RSP-320-12, nominal 12 V.
- Switch: 53.5 V / 1.31 A electrical requirement.
- Other main outputs: Jetson 12 V / 5 A; SG4A 12 V with 4 A design allowance; fan 12 V / 0.14 A; fused 12 V feed to USB board.
- USB: two USB-A charge-only ports, 5 V / 3 A electrical capacity per port. Charging compatibility is not yet established for the headset.
- Inter-board cable length was not supplied. A 1 m one-way AWG16 pair is a provisional design basis, not a confirmed installation dimension.

## Findings that prevent release of the existing drafts

1. The inherited Murata OKR-T/10-W12-C footprint has five pads on 2.54 mm pitch. The manufacturer drawing shows 1.7 mm pitch. The inherited top-view body also treats the module's 16.5 mm height as a board-plane dimension. The D1 USB package must not be fabricated with this footprint.
2. The OKR-T/10-W12-C is obsolete. Its replacement has not been implemented or sourced for assembly.
3. The provisional Molex USB connector's 3 A rating was not established. A verified electrical candidate is Wurth 614004190021: 3 A on pins 1 and 4. Its land pattern needs to be captured and checked against the manufacturer's component-view drawing.
4. Main-board D0 contains a boost-converter functional block, not a completed converter. Compensation, current limit, fault interruption, thermal layout and routing remain engineering work.
5. Both boards are unrouted. The inherited custom input-terminal footprint needs independent mechanical verification. A prior text-level check is not KiCad ERC or DRC.
6. No Gerber/drill/assembly release or verified assembly supplier parts mapping exists. Old source-revision fabrication previews must not be used for these new boards.

## Candidate replacement and reference basis

TI TPSM63610RDFR is an active 8 A continuous / 10 A peak buck power module. It is a candidate for the 6 A shared USB supply, not a drop-in replacement for the Murata. Its reference application uses two 10 uF input capacitors and three 47 uF output capacitors, with a dedicated thermal land pattern. Selection still requires layout, thermal and assembler sourcing checks. The old 267-ohm trim resistor cannot be carried into this circuit.

TI PMP21274 is the main boost reference. Its 54 V / 2.5 A design and validation do not automatically validate a smaller 53.5 V implementation. The original mechanical outline is fixed; any adapted converter must be fitted and rechecked within it.

## Sources checked

- Murata mechanical drawing, page 7: https://pim.murata.com/asset/pim4/nonIsolatedDCDCconverter/OKR-T10-W12_PDF_NONISOLATEDDCDCCONVERTER?lastModifiedDatetime=20250707193528
- Murata lifecycle listing: https://www.digikey.com/en/products/detail/murata-power-solutions-inc/OKR-T-10-W12-C/2199630
- Wurth connector drawing: https://www.we-online.com/components/products/datasheet/614004190021.pdf
- Wurth active product listing: https://www.we-online.com/en/components/products/INPUT_OUTPUT_WR_USB_STANDARD
- TI buck datasheet: https://www.ti.com/lit/ds/symlink/tpsm63610.pdf
- TI boost reference: https://www.ti.com/tool/PMP21274
- KiCad IPC limitations: https://dev-docs.kicad.org/en/apis-and-binding/ipc-api/for-addon-developers/

## Verification access

The official KiCad IPC Python client is installed only in the task's work directory, using the separate Codex runtime. No KiCad executable or KiCad-bundled Python was launched during this review. The user enabled the API. Two read-only connection attempts returned `ConnectionError: Failed to connect to KiCad: Permission denied`. The additional permission request granted read access to the local connection directory but did not grant write access; the retry still failed. No board has been read or modified through IPC. This is an access limitation, not evidence that the user's setting is wrong. KiCad 10 IPC can inspect/edit the board but cannot export fabrication files or inspect schematics; those tasks still need a working GUI or command-line workflow.

Completion requires the actual circuit redesign and routing as well as successful tool checks. Establishing the IPC connection alone does not make either board order-ready. Prototype electrical and thermal testing is separate from readiness to order a first prototype.
