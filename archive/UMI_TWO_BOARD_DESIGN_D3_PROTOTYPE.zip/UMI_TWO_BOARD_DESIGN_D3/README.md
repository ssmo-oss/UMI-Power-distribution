# UMI two-board design — D3 refined prototype package

Completed 2026-09-26. Open MAIN_POWER/MAIN_POWER.kicad_pro and USB_POWER/USB_POWER.kicad_pro. These are two different boards. D1, D2 and UMI_USB_D2 projects are superseded for this revision.

## Delivered

- MAIN_POWER: 158 x 100.263962 mm; 4 layers, 1.2 mm; 65 electrical components (53 SMT, 12 hand fitted).
- USB_POWER: 80 x 50 mm; 4 layers, 1.6 mm; 34 electrical components (31 SMT, 3 hand fitted).
- Editable KiCad projects and local libraries, schematics, filled routed boards, Gerbers, plated/non-plated drills, paste, BOMs, corrected placement files, review images/PDFs and verification reports.
- Both final saved boards pass KiCad 10.0.6 DRC and schematic parity with zero reported violations/unconnected items. Both schematics pass ERC with zero reported violations, using the included project settings. Reports list disabled check categories; this is not a claim that every optional KiCad check was enabled.
- Independent exported-file checks match all 133 main-board and 137 USB-board holes and all 53/31 SMT placement centres to their boards.

## Ordering status

Bare-board manufacturing files are prepared for a first prototype. Read MANUFACTURING_SPECIFICATION.md before obtaining a quote: both boards require 2 oz outer/1 oz inner copper and filled/capped vias, and their thicknesses differ.

Assembly BOM and corrected CPL files are prepared for quoting. The assembly order still requires the supplier to resolve blank catalog codes against exact MPNs and approve its placement preview and process. No stock has been reserved, quote approved or order placed. Use *_CPL_JLC.csv; native *_positions.csv retain local footprint rotations and are reference exports only.

This is not a physically qualified production design. No boards have been fabricated or electrically load-tested. Follow ENGINEERING_AND_TEST_NOTES.md for current-limited bring-up, short/load-step and 40 C enclosure testing before connecting valuable equipment. Confirm the switch accepts the actual output range and test the intended headset charging behaviour; USB-A charging identification is not USB PD.

## Files to send

1. Each board's *_GERBERS.zip for bare-board quote, together with MANUFACTURING_SPECIFICATION.md.
2. BOM_JLC_DRAFT.csv and assembly/*_CPL_JLC.csv for SMT quote, plus top paste and orientation notes. Blank part codes are deliberate sourcing items.
3. Keep the board-mounted through-hole BOM and MANUAL_FUSES_AND_HARNESS_BOM.csv for hand assembly.

Review images show exported copper/pads, not proof of assembled clearance. Some optional 3D bodies are absent; use the footprint/mechanical dimensions. Use the reference-only assembly drawings in each review folder and the BOM for part values.

## D3 layout refinement

Open LAYOUT_REVIEW.html for a before/after comparison rendered from the actual fabrication layers.

The main power bus and long output runs have cleaner 45-degree approaches. Connector functions, fuse values and polarity are marked, and the main board has 3 mm corner radii. Its mounting-hole centres are retained. The USB board has consistent reference placement, matched port legends, five chamfered backside bends and symmetric mounting columns. USB hole centres are x=13.5/86.5 mm, y=14/56 mm in KiCad board coordinates; use the current outline/drills when making the enclosure.

The electrically sensitive converter placement and short switching/ESD paths were retained. Aesthetic refinement is not a claim of perfection or physical qualification. Fresh revision-specific DRC/ERC and export audits are included.

The USB charge-identification routes were redrawn to remove the shield-hole detour: the right pair now uses 6 segments instead of 65, on In2.Cu with the original endpoint vias. The uninterrupted In1.Cu ground reference and converter placement are retained.
