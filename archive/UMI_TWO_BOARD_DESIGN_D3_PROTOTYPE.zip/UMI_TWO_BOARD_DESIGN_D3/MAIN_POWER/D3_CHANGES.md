# D3 main-board refinement

Based on the saved, checked D2 board. The TI converter component placement, current loops, protection circuit and original mounting holes are retained. This revision adds service labels, fuse values, plug polarity, a component key, consistent distribution-bus chamfers and 3 mm corner radii. Dense SMT values are hidden in the assembly view.

Fresh native electrical/geometry checks and manufacturing exports have been regenerated for this revision; all reported checks pass. This is an engineering prototype, not a tested production design.
