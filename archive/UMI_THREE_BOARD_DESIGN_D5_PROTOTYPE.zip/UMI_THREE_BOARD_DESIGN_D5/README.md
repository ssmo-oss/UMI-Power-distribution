# UMI D5 — three-board prototype revision

D5 splits the system into a passive 12 V distribution board, a separate 12 V → 53.5 V PoE-switch supply, and the two-port USB supply. Open **LAYOUT_REVIEW.html** for board images and schematic/assembly drawings. This package replaces D4 for this architecture; older revisions remain separate.

## Boards and connections

| Board | Size | Purpose | SMT / through-hole parts |
|---|---|---|---|
| MAIN_POWER | 68 × 100.264 mm | 12 V input and five fused outputs | 0 / 11 |
| POE_POWER | 106 × 100 mm | Protected 53.5 V boost supply | 53 / 3 |
| USB_POWER | 80 × 50 mm | Two charge-only USB-A sockets | 31 / 3 |

MAIN retains the original mounting-hole centres. POE has its own mounting pattern. USB remains larger than the initial 30 × 60 mm suggestion under the later permission to expand. Mechanical holes are excluded from the component counts.

Connect the external 12 V PSU to MAIN J1. MAIN J2 supplies Jetson, J3 GMSL, J4 fan, J5 USB J1, and J6 POE J1. Each 12 V connector uses pin 1 positive and pin 2 ground. POE J6 is different: pin 1 +53.5 V, pin 2 unused, pin 3 ground. Use the delivered pin schedules and label both harness ends by board name and voltage.

**Use PoE or GMSL, never both in one configuration.** This is a manual configuration rule; the boards do not enforce it electronically. With 90% assumed converter efficiency and the documented load allowances, the larger PoE configuration needs approximately **173.6 W / 14.46 A at 12 V**. Static boost tolerance raises that estimate to approximately 174.5 W / 14.54 A. These are planning estimates, not measured worst-case results. The 20 A input-path design/test target is retained for margin.

## Fuse decision

Keep all six fuses for now: MAIN F1 Jetson 7.5 A, F2 GMSL 7.5 A, F3 fan 1 A, F4 USB 5 A, F5 PoE feed 10 A; POE F6 output 3 A / 80 V. **Unlike the sketch, the PoE feed fuse is on MAIN, at the source of the interboard cable**, so it protects that cable too. There is no duplicate fuse at the POE input; the local electronic protection remains.

Jetson's 7.5 A is a provisional fuse rating, not its load requirement. A 5 A fuse carrying the full 5 A allowance has no demonstrated startup/temperature margin at the stated 40 °C enclosure ambient. Confirm actual current, inrush and the weakest wire segment before reducing it. The mutually exclusive loads reduce the overall budget but do not remove individual branch fault risks. The separate 53.5 V output fuse cannot be declared redundant solely because the converter has an input eFuse. See ENGINEERING_AND_TEST_NOTES.md and verification/d5_electrical_review.md for rationale and sources.

## Checks completed

All three finished boards pass KiCad DRC and ERC: zero violations, zero unconnected items and zero schematic parity issues. Export source hashes match the delivered sources. Independent Gerber/drill checks match all four copper layers, hole locations/sizes and SMT placement centres: MAIN 63 holes / 0 SMT placements, POE 78 / 53, USB 137 / 31. The POE extraction retains the converter's critical copper; the preservation report records the comparison. Assembly references and top/bottom Gerber previews are included.

Use each board's `*_GERBERS.zip` for the fabrication files. POE and USB have assembly paste exports and normalized `*_CPL_JLC.csv`; use the normalized file, not raw KiCad rotations. MAIN is entirely through-hole and has no SMT assembly operation. Review supplier pin-1/orientation previews before assembly approval. Manufacturing settings differ: MAIN/POE 1.2 mm; USB 1.6 mm; all four-layer, 2 oz outer / 1 oz inner. POE and USB require resin-filled, copper-capped pad vias. MAIN does not.

## Procurement and release status

The single UMI_COMPONENT_SOURCING.xlsx list covers all three boards and manual/harness parts, assuming **ten of each board**. It contains dated JLC catalogue observations, not reserved stock. MAIN J1 Phoenix 1709681 and POE R1 ERJ-12ZYJ7R5U remain preorder items; the resistor has a 734-piece purchase minimum. POE F6 has only ten observed inserts and no spare buffer; C1/L1 also have limited headroom. JLC library inventory is for assembly and cannot simply be delivered loose, so the hand-fit/harness supply arrangement still needs resolution.

**These are untested prototype files, not a production-qualified release.** Physical thermal, transient, startup, protection and real-device tests remain, along with procurement and manufacturer quote acceptance. No order, upload, reservation or payment has been made. Review MANUFACTURING_SPECIFICATION.md, MANUAL_ASSEMBLY.md and ENGINEERING_AND_TEST_NOTES.md before procurement or bring-up. SHA256SUMS.txt identifies the packaged files.
